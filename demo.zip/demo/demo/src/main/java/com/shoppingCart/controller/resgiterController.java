package com.shoppingCart.controller;

import com.shoppingCart.entity.register;
import com.shoppingCart.service.registerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class resgiterController {
    @Autowired
    registerService rs;


    Object a;
    @GetMapping("/find")
    public List<register> findAllData(){
        return rs.getAllData();
    }

    @PostMapping("/saveUser")
    public register saveUserDetails(@RequestBody register rg){
        return rs.saveUser(rg);
    }

    @GetMapping("/userByEmailId/{email}")
    public register findUserByEmail( @PathVariable("email") String email) {
        if (rs.findUserByEmail(email) == null) {
            System.out.println("null");
            return null;
        } else {
            return rs.findUserByEmail(email);
        }
    }
}
