package com.shoppingCart.service;

import com.shoppingCart.entity.register;
import com.shoppingCart.repository.registerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class registerService {
    @Autowired
    registerRepository repo;

    register r1=new register();

    public List<register> getAllData(){
        return  repo.findAll();
    }

    public register saveUser(register rs){
        return repo.save(rs);
    }

    public register findUserByEmail(String email){
        return repo.findByEmail(email);
    }



}
