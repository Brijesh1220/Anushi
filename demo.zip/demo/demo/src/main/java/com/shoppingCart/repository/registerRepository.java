package com.shoppingCart.repository;

import com.shoppingCart.entity.register;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface registerRepository extends MongoRepository <register,String> {
    public register findByEmail(String email);
}
