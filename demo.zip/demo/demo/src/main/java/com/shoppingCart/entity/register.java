package com.shoppingCart.entity;

import lombok.*;
import org.springframework.data.annotation.Id;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class register {
    @Id
    private String id;
    private String name;
    private String username;
    private String password;
    private String address;
    private String state;
    private String country;
    private String zipcode;
    private String email;
    private String mobile;
    private String alternativeMobile;
}
