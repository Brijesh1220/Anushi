import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  signUpForm!: FormGroup;

  constructor(private fb: FormBuilder,private AuthS:AuthService) {}

  ngOnInit(): void {
    this.formInit();
  }

  formInit() {
    this.signUpForm = this.fb.group({
      name: '',
      email: '',
      mobile: '',
      password: '',
    });
  }

  onFormSubmit() {
    console.log(this.signUpForm.value);
    this.AuthS.registerData(this.signUpForm.value).subscribe((result:any)=>{
      console.log('Save',result);

    });
  }
}
