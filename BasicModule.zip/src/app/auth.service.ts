import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient) {}
  base_url = 'http://localhost:3000/Api/';

  registerData(data: any) {
    let api_url = this.base_url + 'register';
    const httpOptions = {
      headers: new HttpHeaders({
        'content-type': 'application/json',
        'Access-Control-Allow-Origin':'*'
      }),
    };
    return this.http.post(api_url, data, httpOptions);
  }


}
