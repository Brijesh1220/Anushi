import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  signUpForm!: FormGroup;
  isValidFormSubmitted: any;
  isValidbutton: any;
  constructor(private fb: FormBuilder,private AuthS:AuthService) {}

  ngOnInit(): void {
    this.formInit();
  }

  formInit() {
    this.signUpForm = this.fb.group({
      name: ['',[ Validators.pattern('/^[a-zA-Z]*$/')]],
      username: '',
      address: '',
      state: '',
      country: '',
      zip: '',
      email:['',[ Validators.pattern('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$')]],
      mobile: ['', [Validators.required, Validators.pattern('^[6-9][0-9]{9}$')]],
      password: '',
    });
  }
  get f() {
    return this.signUpForm.controls;
  }
  // onFormSubmit() {
  //   console.log(this.signUpForm.value);
  //   this.AuthS.registerData(this.signUpForm.value).subscribe((result:any)=>{
  //     console.log('Save',result);

  //   });
  // }
  onFormSubmit() {
    this.isValidFormSubmitted = false;
    if (this.signUpForm.invalid) {
      console.log(this.signUpForm,'error');
      this.isValidFormSubmitted = true;
      this.isValidbutton = false;
     
    } else {
      console.log(this.signUpForm,'true');
      this.isValidbutton = true;
     
      this.AuthS.registerData(this.signUpForm.value).subscribe((result:any)=>{
           console.log('Save',result);
      
          });
    }
  
  }
}




