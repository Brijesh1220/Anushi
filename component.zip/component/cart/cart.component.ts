import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  public products : any = [];
  public grandTotal !: number;
  constructor(private cartService : CartService) { }

  ngOnInit(): void {
    this.cartService.getProducts()
    .subscribe(res=>{
      this.products = res;
      this.grandTotal = this.cartService.getTotalPrice();
      console.log(this.products);

    })
  }
  removeItem(item: any){
    this.cartService.removeCartItem(item);
  }
  emptycart(){
    this.cartService.removeAllCart();
  }
  getValid(e:any,i:any){
    let qty=e.target.value;
    if(parseInt(qty)<0){
      console.log('00000')
      this.products[i].quantity=0;
      this.products[i].total=0;
      this.grandTotal = this.cartService.getTotalPrice();
      e.target.value=0;
      // return 0;
    }
    else{
       console.log('9999999999');
      this.products[i].quantity = qty;
      this.products[i].total = this.products[i].price*qty;
      this.grandTotal = this.cartService.getTotalPrice();
    }
    console.log(this.products);

  }

}
